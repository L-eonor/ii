package MES;

import javax.sound.midi.Soundbank;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import static MES.Main.*;
import static java.lang.Thread.*;

public class UnloadThread implements Runnable {

    //Attributes
    static boolean bigFlagP1P9Init=true;
    static boolean bigFlagP1P9End=false;
    static int  countCollumns=1;
    static int[] warehouseOut = {1, 1};
    static int[] warehouseIn = {0, 7};
    String actionPush = "99";

    TransformationsGraph transformTable = new TransformationsGraph();
    /*
    List<orderTransform> orderListTransformationEnded = Main.orderListTransformationEnded;
    List<orderUnload> orderListUnload = Main.orderListUnload;
     */

    public UnloadThread() {

    }

    public void run() {
        System.out.println("--------------[Executing] UnloadThread is Running [Executing]--------------");
        //Tells TransformationThread to immediately wait

        while (true) {

            //System.out.println(" - 1 : "+ !Main.orderListUnload.isEmpty() +" "+!checkIfWaiting()+" "+ piecesAvailableForOneUnload());
            //System.out.println(" - 2 : "+!Main.ordersPriority.isEmpty()+ " "+ !piecesAvailableForOutofUnits());
            //System.out.println(" - 3 : "+ !orderListTransformationOutOfUnits.isEmpty() +""+ piecesAvailableForOutofUnits());

            if(!Main.orderListUnload.isEmpty() && !checkIfWaiting()) {

                orderUnload order = Main.orderListUnload.remove(0);

                //Order attributes
                int orderUnitsDone = order.getNDone();
                int orderUnitsTotal = order.getQuantity();
                String orderPx = order.getPx();

                //Identify and relate Dy with respective position of Slider
                String orderDy = order.getDy();
                int[] goal = SFS.getUnloadPosition(orderDy);
                if (goal == null) System.out.println("Error: order machine input not valid. ");
                Slider slider = (Slider) SFS.getCell(goal[1],goal[0]);


                if(!slider.isFull() && Warehouse.getPiece(order.getPx()) > 0) {
                    //Mark down start timing
                    if(orderUnitsDone == 0) order.setStartTime(StopWatch.getTimeElapsed());

                    //Update order status to "in progress".
                    if(order.getStatus() != 2) order.setStatus(2);

                    //Update order in db
                    dbConnection.updateStatus_OrderUnloadDB(order.getId(), order.getStatus());

                    //Calculate path to Slider (every Unload order unit has the same path)
                    StringBuilder pathStringBuilder = new StringBuilder();


                    if(order.getDy().equals("D1")){
                        //System.out.println("Calculating path.......");
                        int[] a={7,1};
                        Path_Logic path = new Path_Logic(warehouseOut, a, "Unload", (orderUnitsTotal - orderUnitsDone));
                        pathStringBuilder.append(path.getStringPath());
                        path = new Path_Logic(a, goal, "Unload", (orderUnitsTotal - orderUnitsDone));
                        pathStringBuilder.append(path.getStringPath());
                    }
                    else if(order.getDy().equals("D2")) {
                        //System.out.println("Calculating path.......");
                        Path_Logic path = new Path_Logic(warehouseOut, goal, "Unload", (orderUnitsTotal - orderUnitsDone));
                        pathStringBuilder.append(path.getStringPath());
                    }
                    else if(order.getDy().equals("D3")){
                        //System.out.println("Calculating path.......");
                        int[] a={6,6};
                        Path_Logic path = new Path_Logic(warehouseOut, a, "Unload", (orderUnitsTotal - orderUnitsDone));
                        pathStringBuilder.append(path.getStringPath());
                        path = new Path_Logic(a, goal, "Unload", (orderUnitsTotal - orderUnitsDone));
                        pathStringBuilder.append(path.getStringPath());
                    }

                    //Adds "99" action to the pusher
                    String pathString = pathStringBuilder.toString().replaceFirst(".{2}$", actionPush);

                    // Adds order info to the end
                    pathString += order.getPx() + "2" + order.getId();

                    System.out.println("[Unload] Esta é a string: " + pathString);

                    for (int a = orderUnitsDone; a < orderUnitsTotal; a++) {
                        //System.out.println(" # # # # # # # # # # # # ");

                        //Condition to verify when Slider is full or no more units are available to send
                        if (slider.isFull() || (Warehouse.getPiece(order.getPx()) <= 0)) {
                            order.setStatus(2);
                            Main.orderListUnload.add(order);
                            break;
                        }

                        //Sends information to OPC-UA

                        sendPathToOPC(unitTypeIdentifier(orderPx), pathString);


                        //Updates Unload order information
                        orderUnitsDone++;
                        order.setNDone(orderUnitsDone);

                        //Update Unload Order on DataBase
                        dbConnection.updateNDone_OrderUnloadDB(order.getId(), orderUnitsDone);

                        //System.out.println(" # # # # # # # # # # # # ");

                    }

                }
                else {
                    Main.orderListUnload.add(order); //adds order to top of Unload List
                }

                //Checks if order is done and updates Order
                if(order.getQuantity() == order.getNDone()) {
                    order.setStatus(3); //Set order status to "All pieces sent".
                    Main.orderListUnloadEnded.add(order);

                    //Update order in db
                    dbConnection.updateStatus_OrderUnloadDB(order.getId(), order.getStatus());
                }

            }
            /*else if (!orderListTransformationOutOfUnits.isEmpty() && piecesAvailableForOutofUnits()) {

                orderTransform order = orderListTransformationOutOfUnits.remove(0);

                //Order attributes
                int orderUnitsDone = order.getNDone();
                int orderUnitsTotal = order.getNTotal();
                String orderPx = order.getPx();
                String orderPy = order.getPy();

                if(Warehouse.getPiece(orderPx) > 0) {
                    System.out.println("WareHouse Pieces > 0");
                    while (orderUnitsDone <= orderUnitsTotal) {
                        System.out.println("A fazer a ordem.");

                        //Verifies if orderUnitsDone = orderUnitsTotal and if yes, polls and updates Order
                        if (order.getNDone() == order.getNTotal()) {
                            order.setStatus(3); //Set order status to "All pieces sent".
                            //System.out.println(order);
                            Main.orderListTransformationEnded.add(order);
                            break;
                        }

                        //Verifies if it's out of units
                        if(Warehouse.getPiece(orderPx) <= 0){
                            order.setStatus(2); //Set order status to "All pieces sent".
                            orderListTransformationOutOfUnits.add(order);
                            break;
                        }

                        //Verifies if an Unload Order came in
                        if (!Main.orderListUnload.isEmpty() && !checkIfWaiting() && piecesAvailableForOneUnload()) {
                            order.setStatus(2); //Set order status to "in pause".
                            orderListTransformationOutOfUnits.add(order);
                            break;
                        }

                        //System.out.println(" # # # # # # # # # # # # ");

                        if (orderUnitsDone == 0) order.setStartTime(StopWatch.getTimeElapsed()); //Set order start Time
                        if (order.getStatus() != 2) order.setStatus(2); //Set order status to "in progress".

                        //Finds transformations to do
                        if (transformTable.searchTransformations(orderPx, orderPy)) {
                            //System.out.println("Searched transformations. Found " + transformTable.solutions.size() + " solutions.");
                        } else System.out.println(" No need for transformations. ");

                        //String with the whole path of the Transformation order
                        StringBuilder pathString = new StringBuilder();

                        //Retrieves transformations with lowest time cost
                        GraphSolution transformationResult = transformTable.solutions.poll();
                        if (transformationResult == null)
                            throw new AssertionError("Error: transformationResult null pointer.");


                        //Starts finding path according to transformations
                        Machine machineToGo;
                        int[] startTransformation = warehouseOut;
                        int[] goalTransformation = {0, 0};
                        String previousMachine = "";

                        for (int j = 0; j < transformationResult.transformations.size(); j++) {

                            //Identify machine
                            String machineNow = transformationResult.machines.get(j);

                            //Relate machine type with respective position
                            if (!previousMachine.equals(machineNow)) {
                                machineToGo = SFS.getMachineToSendPiece(machineNow);
                                goalTransformation = reverseArray(machineToGo.getPosition());
                                if (goalTransformation == null)
                                    System.out.println("Error: order machine input not valid. ");
                                else {
                                    machineToGo.addWeight();
                                }

                                //Calculate path to Machine
                                Path_Logic path = new Path_Logic(startTransformation, goalTransformation, "Transformation");
                                pathString.append(path.getStringPath());
                                previousMachine = machineNow;
                            } else {
                                String machinePositionString = String.valueOf(goalTransformation[0]) + String.valueOf(goalTransformation[1]);
                                pathString.append(machinePositionString);
                            }

                            //Add Tool and Time to string respectively
                            pathString.append(transformationResult.tool.get(j)).append(transformationResult.timeCost.get(j));
                            startTransformation = goalTransformation;
                        }

                        //Path to Warehouse In cell
                        Path_Logic pathEnd = new Path_Logic(startTransformation, warehouseIn, "Transformation");
                        pathString.append(pathEnd.getStringPath());
                        // Adds order info to the end
                        String orderInfo = order.getPy() + "1" + order.getId();
                        pathString.append(orderInfo);

                        System.out.println("[Transformation] Esta é a string: " + pathString);


                        //Sends information to OPC-UA
                        sendPathToOPC(unitTypeIdentifier(orderPx), pathString.toString());

                        //Updates order information
                        orderUnitsDone++;
                        order.setNDone(orderUnitsDone);

                        //System.out.println(" # # # # # # # # # # # # ");
                        //System.out.println();

                    }
                }
                else {
                    order.setStatus(3); //Set order status to "All pieces sent".
                    orderListTransformationOutOfUnits.add(order);
                }

            }*/
            else if (!Main.ordersPriority.isEmpty()) {
                int index = getMaxPriority();
                orderTransform order= ordersPriority.get(index);

                //Order is now processing
                order.setStatus(2);

                //Update order in db
                dbConnection.updateStatus_OrderTransformDB(order.getId(), order.getStatus());


                //Order attributes
                int orderUnitsDone = order.getNDone();
                int orderUnitsTotal = order.getNTotal();
                String orderPx = order.getPx();
                String orderPy = order.getPy();
                int orderUnitsToDo= orderUnitsTotal-orderUnitsDone;
                int orderCountAux=1;

                if(Warehouse.getPiece(orderPx) > 0) {
                    while (orderUnitsDone <= orderUnitsTotal) {

                        //Verifies if orderUnitsDone = orderUnitsTotal and if yes, polls and updates Order
                        if (order.getNDone() == order.getNTotal()) {
                            order.setStatus(3); //Set order status to "All pieces sent".
                            //System.out.println(order);
                            Main.orderListTransformationEnded.add(Main.ordersPriority.remove(index));
                            //Update order in db
                            //dbConnection.updateStatus_OrderTransformDB(order.getId(), order.getStatus());
                            break;
                        }

                        //Verifies if it's out of units
                        if(Warehouse.getPiece(orderPx) <= 0){
                            order.setStatus(3); //Set order status to "All pieces sent".
                            orderListTransformationOutOfUnits.add(Main.ordersPriority.remove(index));
                            break;
                        }

                        //Verifies if an Unload Order came in
                        if (!Main.orderListUnload.isEmpty() && !checkIfWaiting()) {
                            order.setStatus(2); //Set order status to "in pause".
                            break;
                        }

                        //Verifies if a Transform Order order with higher priority came in
                        int indexAux = getMaxPriority();
                        if (indexAux != index) {
                            order.setStatus(2); //Set order status to "in pause".

                            break;
                        }

                        if (orderUnitsDone == 0) order.setStartTime(StopWatch.getTimeElapsed()); //Set order start Time
                        if (order.getStatus() != 2) order.setStatus(2); //Set order status to "in progress".

                        String pathString;

    /*


                        //Finds transformations to do
                        if (transformTable.searchTransformations(orderPx, orderPy)) {
                        /* prints all transformations
                        Iterator value = transformTable.solutions.iterator();
                        while(value.hasNext()) {
                            System.out.println(transformTable.solutions.poll());
                        }
                        } else System.out.println(" No need for transformations. ");

                        //String with the whole path of the Transformation order
                        StringBuilder pathString = new StringBuilder();

                        //Retrieves transformations with lowest time cost
                        GraphSolution transformationResult = transformTable.solutions.poll();
                        if (transformationResult == null)
                            throw new AssertionError("Error: transformationResult null pointer.");


                        //Starts finding path according to transformations
                        Machine machineToGo;
                        int[] startTransformation = warehouseOut;
                        int[] goalTransformation = {0, 0};
                        String previousMachine = "";

                        String aux="";
                        int sameMachine=1;
                        int lastSameMachine=0;

                        for(int a=0; a < transformationResult.transformations.size(); a++) {

                            String machineNow = transformationResult.machines.get(a);
                            if (aux.equals(machineNow)) {
                                sameMachine++;
                                lastSameMachine=a;
                            }
                            aux=machineNow;
                        }

                        for (int j = 0; j < transformationResult.transformations.size(); j++) {

                            if(sameMachine == 1) {
                                if(count==1){
                                    if(transformationResult.machines.get(j).equals("Ma")) {
                                        int[] p={1,3};
                                        Path_Logic count1 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count1.getStringPath());
                                        goalTransformation=cloneArray(p);
                                    }
                                    else if(transformationResult.machines.get(j).equals("Mb")){
                                        int[] p={1,4};
                                        Path_Logic count2 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count2.getStringPath());
                                        goalTransformation=cloneArray(p);
                                    }
                                    else if(transformationResult.machines.get(j).equals("Mc")){
                                        int[] p={1,5};
                                        Path_Logic count3 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count3.getStringPath());
                                        goalTransformation=cloneArray(p);
                                    }
                                }
                                else if(count == 2){
                                    if(transformationResult.machines.get(j).equals("Ma")) {
                                        int[] p={3,3};
                                        Path_Logic count1 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count1.getStringPath());
                                        goalTransformation=cloneArray(p);
                                    }
                                    else if(transformationResult.machines.get(j).equals("Mb")){
                                        int[] p={3,4};
                                        Path_Logic count2 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count2.getStringPath());
                                        goalTransformation=cloneArray(p);

                                    }
                                    else if(transformationResult.machines.get(j).equals("Mc")){
                                        int[] p={3,5};
                                        Path_Logic count3 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count3.getStringPath());
                                        goalTransformation=cloneArray(p);
                                    }
                                }
                                else if (count == 3) {
                                    if(transformationResult.machines.get(j).equals("Ma")) {
                                        int[] p={5,3};
                                        Path_Logic count1 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count1.getStringPath());
                                        goalTransformation=cloneArray(p);
                                    }
                                    else if(transformationResult.machines.get(j).equals("Mb")){
                                        int[] p={5,4};
                                        Path_Logic count2 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count2.getStringPath());
                                        goalTransformation=cloneArray(p);

                                    }
                                    else if(transformationResult.machines.get(j).equals("Mc")){
                                        int[] p={5,5};
                                        Path_Logic count3 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count3.getStringPath());
                                        goalTransformation=cloneArray(p);
                                    }

                                }

                            }
                            else if(sameMachine == 2){
                                if(count==1 || count == 3){
                                    if(transformationResult.machines.get(j).equals("Ma")) {
                                        int[] p={1,3};
                                        if(lastSameMachine == j) {p[0]=3;}
                                        Path_Logic count1 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count1.getStringPath());
                                        goalTransformation=cloneArray(p);
                                    }
                                    else if(transformationResult.machines.get(j).equals("Mb")){
                                        int[] p={1,4};
                                        if(lastSameMachine == j) {p[0]=3;}
                                        Path_Logic count2 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count2.getStringPath());
                                        goalTransformation=cloneArray(p);
                                    }
                                    else if(transformationResult.machines.get(j).equals("Mc")){
                                        int[] p={1,5};
                                        if(lastSameMachine == j) {p[0]=3;}
                                        Path_Logic count3 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count3.getStringPath());
                                        goalTransformation=cloneArray(p);
                                    }
                                }
                                else if (count == 2) {
                                    if(transformationResult.machines.get(j).equals("Ma")) {
                                        int[] p={5,3};
                                        if(lastSameMachine == j) {p[0]=3;}
                                        Path_Logic count1 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count1.getStringPath());
                                        goalTransformation=cloneArray(p);
                                    }
                                    else if(transformationResult.machines.get(j).equals("Mb")){
                                        int[] p={5,4};
                                        if(lastSameMachine == j) {p[0]=3;}
                                        Path_Logic count2 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count2.getStringPath());
                                        goalTransformation=cloneArray(p);

                                    }
                                    else if(transformationResult.machines.get(j).equals("Mc")){
                                        int[] p={5,5};
                                        if(lastSameMachine == j) {p[0]=3;p[1]=3;}
                                        Path_Logic count3 = new Path_Logic(startTransformation, p, "Transformation");
                                        pathString.append(count3.getStringPath());
                                        goalTransformation=cloneArray(p);
                                    }
                                }

                            }
                            else if(sameMachine == 3){
                                if(transformationResult.machines.get(j).equals("Ma")) {
                                    int[] p={1,3};
                                    if(j==1) p[0]=3;
                                    if(j==2) p[0]=5;
                                    Path_Logic count1 = new Path_Logic(startTransformation, p, "Transformation");
                                    pathString.append(count1.getStringPath());
                                    goalTransformation=cloneArray(p);
                                }
                                else if(transformationResult.machines.get(j).equals("Mb")){
                                    int[] p={1,4};
                                    if(j==1) p[0]=3;
                                    if(j==2) p[0]=5;
                                    Path_Logic count2 = new Path_Logic(startTransformation, p, "Transformation");
                                    pathString.append(count2.getStringPath());
                                    goalTransformation=cloneArray(p);
                                }
                                else if(transformationResult.machines.get(j).equals("Mc")){
                                    int[] p={1,5};
                                    if(j==1) p[0]=3;
                                    if(j==2) p[0]=5;
                                    Path_Logic count3 = new Path_Logic(startTransformation, p, "Transformation");
                                    pathString.append(count3.getStringPath());
                                    goalTransformation=cloneArray(p);
                                }

                            }

                            //Identify machine
                            //String machineNow = transformationResult.machines.get(j);
                            /*
                            //Relate machine type with respective position
                            if (!previousMachine.equals(machineNow)) {
                                machineToGo = SFS.getMachineToSendPiece(machineNow);
                                goalTransformation = reverseArray(machineToGo.getPosition());
                                if (goalTransformation == null)
                                    System.out.println("Error: order machine input not valid. ");
                                else {
                                    machineToGo.addWeight(1);
                                }

                                //Calculate path to Machine
                                Path_Logic path = new Path_Logic(startTransformation, goalTransformation, "Transformation");
                                pathString.append(path.getStringPath());
                                previousMachine = machineNow;
                            }
                            else {
                                String machinePositionString = String.valueOf(goalTransformation[0]) + String.valueOf(goalTransformation[1]);
                                pathString.append(machinePositionString);
                            }




                            //Add Tool and Time to string respectively
                            pathString.append(transformationResult.tool.get(j)).append(transformationResult.timeCost.get(j));
                            startTransformation = cloneArray(goalTransformation);
                        }

                        //Path to Warehouse In cell
                        Path_Logic pathEnd = new Path_Logic(startTransformation, warehouseIn, "Transformation");
                        pathString.append(pathEnd.getStringPath());
                        // Adds order info to the end
                        String orderInfo = order.getPy() + "1" + order.getId();
                        pathString.append(orderInfo);
    */

                        while(bigFlagP1P9End){
                            boolean mA=SFS.getCell(3,1).getUnitPresence();
                            boolean mB=SFS.getCell(4,1).getUnitPresence();
                            boolean mC=SFS.getCell(5,1).getUnitPresence();
                            boolean rA=SFS.getCell(3,2).getUnitPresence();
                            boolean rB=SFS.getCell(4,2).getUnitPresence();
                            boolean rC=SFS.getCell(5,2).getUnitPresence();

                            if(!mA && !rA && !mB && !rB && !mC && !rC){
                                bigFlagP1P9End=false;
                            }
                        }


                        pathString=getPathByTransformation(orderPx,orderPy,orderUnitsToDo,orderCountAux,false);
                        String orderInfo ="1" + order.getId();
                        pathString=pathString+orderInfo;
                        //Sends information to OPC-UA

                        sendPathToOPC(unitTypeIdentifier(orderPx), pathString);

                        orderCountAux++;
                        //Updates order information
                        orderUnitsDone++;
                        order.setNDone(orderUnitsDone);
                        //System.out.println(order);

                        //Update Unload Order on DataBase
                        //dbConnection.updateNDone_OrderTransformationDB(order.getId(), orderUnitsDone);



                        // Displaying the values after iterating through the queue
                        //System.out.println("The iterator values are: ");
                        int i=1;
                        boolean flagA=false, flagB=false,flagC=false, flagDouble=false;
                        String pathDoubleTransf="";
                        orderTransform orderDoubleComp=null;

                        for(int a=0; a < Main.ordersPriority.size(); a++){
                            if(a==index){
                                continue;
                            }

                            orderTransform orderComp = Main.ordersPriority.get(a);

                            // If it's been done, keep looking
                            if(orderComp.getNDone()==orderComp.getNTotal()) continue;

                            String transf = isCompatible(orderPx,orderPy,orderComp.getPx(),orderComp.getPy());
                            if((transf.equals("12") || transf.equals("32")) && !flagB){
                                flagB = true;

                                pathString = getPathByTransformation(orderComp.getPx(), orderComp.getPy(), 1, 1, true);
                                orderInfo ="1" + orderComp.getId();
                                pathString=pathString+orderInfo;

                                if (orderComp.getNDone() == 0) orderComp.setStartTime(StopWatch.getTimeElapsed()); //Set order start Time
                                if (orderComp.getStatus() != 2){
                                    orderComp.setStatus(2);
                                    //Update order in db
                                    //dbConnection.updateStatus_OrderTransformDB(order.getId(), order.getStatus());
                                }

                                //Sends information to OPC-UA
                                sendPathToOPC(unitTypeIdentifier(orderComp.getPx()), pathString);

                                //Updates order information
                                orderComp.setNDone(orderComp.getNDone() + 1);
                                //System.out.println(orderComp);

                                //Update Order on DataBase
                                //dbConnection.updateNDone_OrderTransformationDB(orderComp.getId(), orderComp.getNDone());
                            }
                            else if((transf.equals("13") || transf.equals("23")) && !flagC){
                                flagC = true;

                                pathString = getPathByTransformation(orderComp.getPx(), orderComp.getPy(), 1, 1, true);
                                orderInfo ="1" + orderComp.getId();
                                pathString=pathString+orderInfo;

                                if (orderComp.getNDone() == 0) orderComp.setStartTime(StopWatch.getTimeElapsed()); //Set order start Time
                                if (orderComp.getStatus() != 2){
                                    orderComp.setStatus(2); //Set order status to "in progress".
                                    //Update order in db
                                    //dbConnection.updateStatus_OrderTransformDB(orderComp.getId(), orderComp.getStatus());
                                }

                                //Sends information to OPC-UA
                                sendPathToOPC(unitTypeIdentifier(orderComp.getPx()), pathString);

                                //Updates order information
                                orderComp.setNDone(orderComp.getNDone() + 1);
                                //System.out.println(orderComp);

                                //Update Order on DataBase
                                //dbConnection.updateNDone_OrderTransformationDB(orderComp.getId(), orderComp.getNDone());
                            }
                            else if((transf.equals("21") || transf.equals("31")) && !flagA){
                                flagA = true;

                                pathString = getPathByTransformation(orderComp.getPx(), orderComp.getPy(), 1, 1, true);
                                orderInfo ="1" + orderComp.getId();
                                pathString=pathString+orderInfo;

                                if (orderComp.getNDone() == 0) orderComp.setStartTime(StopWatch.getTimeElapsed()); //Set order start Time
                                if (orderComp.getStatus() != 2){
                                    orderComp.setStatus(2); //Set order status to "in progress".
                                    //Update order in db
                                    //dbConnection.updateStatus_OrderTransformDB(orderComp.getId(), orderComp.getStatus());
                                }

                                //Sends information to OPC-UA
                                sendPathToOPC(unitTypeIdentifier(orderComp.getPx()), pathString);
                                //Updates order information
                                orderComp.setNDone(orderComp.getNDone() + 1);
                                //System.out.println(orderComp);

                                //Update Order on DataBase
                                //dbConnection.updateNDone_OrderTransformationDB(orderComp.getId(), orderComp.getNDone());
                            }

                            //Caso encontre um transformação dupla possível
                            if((transf.equals("123") || transf.equals("312"))  && !flagDouble){
                                orderDoubleComp=ordersPriority.get(a);
                                flagDouble = true;

                                if (orderDoubleComp.getNDone() == 0) orderDoubleComp.setStartTime(StopWatch.getTimeElapsed()); //Set order start Time
                                if (orderDoubleComp.getStatus() != 2){
                                    orderDoubleComp.setStatus(2); //Set order status to "in progress".
                                    //Update order in db
                                    //dbConnection.updateStatus_OrderTransformDB(orderDoubleComp.getId(), orderDoubleComp.getStatus());
                                }

                                pathDoubleTransf = getPathByTransformation(orderComp.getPx(), orderComp.getPy(), 1, 1, true);
                                orderInfo ="1" + orderComp.getId();
                                pathDoubleTransf=pathDoubleTransf+orderInfo;
                            }


                            //Checks if order is done
                            if(orderComp.getNTotal()==orderComp.getNDone()){
                                orderComp.setStatus(3);
                                Main.orderListTransformationEnded.add(ordersPriority.remove(a));
                                //Update order in db
                                //dbConnection.updateStatus_OrderTransformDB(orderComp.getId(), orderComp.getStatus());
                            }

                        }

                        if(!flagA && !flagB && !flagC && flagDouble){
                            //Sends information to OPC-UA
                            sendPathToOPC(unitTypeIdentifier(orderDoubleComp.getPx()), pathDoubleTransf);
                            //Updates order information
                            orderDoubleComp.setNDone(orderDoubleComp.getNDone() + 1);
                            //System.out.println(orderDoubleComp);

                            //Update Order on DataBase
                            //dbConnection.updateNDone_OrderTransformationDB(orderDoubleComp.getId(), orderDoubleComp.getNDone());
                        }



                    }
                }
                else {
                    order.setStatus(3); //Set order status to "All pieces sent".
                    orderListTransformationOutOfUnits.add(Main.ordersPriority.remove(index));
                    //Update order in db
                    //dbConnection.updateStatus_OrderTransformDB(order.getId(), order.getStatus());
                }

            }
        }

    }


    public int unitTypeIdentifier(String Px) {
        switch (Px) {
            case "P1":
                return 1;
            case "P2":
                return 2;
            case "P3":
                return 3;
            case "P4":
                return 4;
            case "P5":
                return 5;
            case "P6":
                return 6;
            case "P7":
                return 7;
            case "P8":
                return 8;
            case "P9":
                return 9;
            default:
                return 0;
        }
    }

    private int[] reverseArray(int[] a) {
        int n = a.length;
        int[] b = new int[n];
        int j = n;
        for (int i = 0; i < n; i++) {
            b[j - 1] = a[i];
            j = j - 1;
        }
        return b;
    }

    private void sendPathToOPC(int unitType, String path){
        //Sends information to OPC-UA
        //Set go a false
        OPCUA_Connection.setValueBoolean("MAIN_TASK", "GO", true);
        OPCUA_Connection.setValueInt("MAIN_TASK", "unit_type", unitType);
        OPCUA_Connection.setValueString("MAIN_TASK", "AT1_order_path_mes", path);
        //System.out.println(path);
        int aux = 1;
        while (true){

            if(aux == 1 && !SFS.getCell(1,0).getUnitPresence()) {
                Main.unitCount++;
                OPCUA_Connection.setValueInt("MAIN_TASK", "UNIT_COUNT_AT1", Main.unitCount);
                aux++;
            }
            if(aux == 2 && OPCUA_Connection.getValueInt("MAIN_TASK", "UNIT_COUNT_AT1") == Main.unitCount){
                aux++;
            }
            if(aux == 3 && (OPCUA_Connection.getValueInt("MAIN_TASK", "CONFIRMATIONGO")==Main.unitCount)) break;
        }

    }

    private boolean checkIfWaiting(){
        boolean waiting=true;
        for(int i=0; i < Main.orderListUnload.size(); i++){
            int[] position = SFS.getUnloadPosition(Main.orderListUnload.get(i).getDy());
            Slider slider = (Slider) SFS.getCell(position[1], position[0]);
            if(!slider.isFull()) {
                waiting=false;
                break;
            }
        }
        return waiting;
    }

    private boolean piecesAvailableForOneUnload(){
        boolean available=false;
        for(int i=0; i < Main.orderListUnload.size(); i++){
            String type = Main.orderListUnload.get(i).getPx();
            int nPieces =Warehouse.getPiece(type);
            if(nPieces >= (Main.orderListUnload.get(i).getQuantity() - Main.orderListUnload.get(i).getNDone())) {
                available=true;
                break;
            }
        }
        return available;
    }

    private boolean piecesAvailableForOutofUnits(){
        boolean available=false;
        for(int i=0; i < orderListTransformationOutOfUnits.size(); i++){
            String type = orderListTransformationOutOfUnits.get(i).getPx();
            int nPieces=Warehouse.getPiece(type);
            if(nPieces >= (orderListTransformationOutOfUnits.get(i).getNTotal()-orderListTransformationOutOfUnits.get(i).getNDone())){
                available=true;
                break;
            }
        }
        return available;
    }

    private int[] cloneArray(int[] a) {
        int[] b = new int[a.length];
        for (int i = 0; i < a.length; i++) {
            b[i] = a[i];
        }
        return b;
    }

    private String getPathByTransformation(String orderPx,String orderPy, int orderUnitsToDo,int orderCountAux, boolean parallel) {
        String path="";
        int countCollumnsInitial=countCollumns;

        if(orderPx.equals("P1")) {

            switch (orderPy) {

                case "P2":
                    if (countCollumns==1){
                        path = "21314151616263531156364656667574737271707P2"; //Ma3

                        countCollumns++;
                    }
                    else if(countCollumns == 2){
                        path = "213141424333115434445464737271707P2"; //Ma2

                        countCollumns++;
                    }
                    else if(countCollumns == 3){
                        path = "2122231311523242526271707P2"; //Ma1
                        countCollumns=1;

                    }
                    break;

                case "P3":
                    if(parallel){
                        if (countCollumns==1){
                            path = "21314151616263645412064656667574737271707P3"; //Mb3
                            countCollumns++;
                        }
                        else if(countCollumns == 2){
                            path="213141424344341204445464737271707P3";//Mb2
                            countCollumns++;
                        }
                        else if(countCollumns == 3){
                            path="2122232414120242526271707P3"; //Mb1
                            countCollumns=1;
                        }

                    }
                    if (countCollumns==1){
                        if (orderCountAux%3 == 1) {
                            path = "21314151616263645412064656667574737271707P3"; //Mb3
                        }
                        else if (orderCountAux%3 == 2) {
                            path = "2131415161626353115531156364656667574737271707P3"; //Ma3
                        }
                        else if (orderCountAux%3 == 0) {
                            path = "21314151616263645412064656667574737271707P3"; //Mb3
                        }
                        if(orderCountAux==orderUnitsToDo || orderCountAux%3== 0){
                            countCollumns++;
                        }
                    }
                    else if(countCollumns == 2){
                        if (orderCountAux%3 == 1) {
                            path="213141424344341204445464737271707P3";//Mb2
                        }
                        else if (orderCountAux%3 == 2) {
                            path = "21314142433311533115434445464737271707P3";//Ma2
                        }
                        else if (orderCountAux%3 == 0) {
                            path="213141424344341204445464737271707P3";//Mb2
                        }
                        if(orderCountAux==orderUnitsToDo || orderCountAux%3== 0){
                            countCollumns++;
                        }
                    }
                    else if(countCollumns == 3){
                        if (orderCountAux%3 == 1) {
                            path="2122232414120242526271707P3";
                        }
                        else if (orderCountAux%3 == 2) {
                            path="212223131151311523242526271707P3";//Ma1
                        }
                        else if (orderCountAux%3 == 0) {
                            path="2122232414120242526271707P3";
                        }
                        if(orderCountAux==orderUnitsToDo || orderCountAux%3== 0){
                            countCollumns=1;
                        }
                    }
                    break;

                case "P4":
                    if(parallel){
                        if (countCollumns==1){
                            path = "21314151616263646555110656667574737271707P4"; //Mc3
                            countCollumns++;
                        }
                        else if(countCollumns == 2){
                            path = "213141424344453511045464737271707P4"; //Mc2
                            countCollumns++;
                        }
                        else if(countCollumns == 3){
                            path = "2122232425151102526271707P4"; //Mc1
                            countCollumns=1;
                        }

                    }

                    else if(orderUnitsToDo <= 3){
                        if (countCollumns==1) {
                            path = "21314151616263646555110656667574737271707P4"; //Mc3
                            if(orderCountAux==orderUnitsToDo){
                                countCollumns++;
                            }
                        }
                        else if (countCollumns==2) {
                            path = "213141424344453511045464737271707P4"; //Mc2
                            if(orderCountAux==orderUnitsToDo){
                                countCollumns++;
                            }
                        }
                        else if (countCollumns==3) {
                            path = "2122232425151102526271707P4"; //Mc1
                            if(orderCountAux==orderUnitsToDo){
                                countCollumns=1;
                            }
                        }

                    }
                    else {
                        if (countCollumns==1){
                            if (orderCountAux%5 == 1) {
                                path = "21314151616263646555110656667574737271707P4"; //Mc3
                            }
                            else if (orderCountAux%5 == 2) {
                                path = "2131415161626364541205411564656667574737271707P4"; //Mb3
                            }
                            else if (orderCountAux%5 == 3) {
                                path = "21314151616263646555110656667574737271707P4"; //Mc3
                            }
                            else if (orderCountAux%5 == 4) {
                                path = "21314151616263646555110656667574737271707P4"; //Mc3
                            }
                            else if (orderCountAux%5 == 0) {
                                path = "21314151616263646555110656667574737271707P4"; //Mc3
                            }
                            if(orderCountAux==orderUnitsToDo || orderCountAux%5== 0){
                                countCollumns++;
                            }
                        }
                        else if(countCollumns == 2){
                            if (orderCountAux%5 == 1) {
                                path = "213141424344453511045464737271707P4"; //Mc2
                            }
                            else if (orderCountAux%5 == 2) {
                                path = "21314142434434120341154445464737271707P4"; //Mb2
                            }
                            else if (orderCountAux%5 == 3) {
                                path = "213141424344453511045464737271707P4"; //Mc2
                            }
                            else if (orderCountAux%5 == 4) {
                                path = "213141424344453511045464737271707P4"; //Mc2
                            }
                            else if (orderCountAux%5 == 0) {
                                path = "213141424344453511045464737271707P4"; //Mc2
                            }
                            if(orderCountAux==orderUnitsToDo || orderCountAux%5== 0){
                                countCollumns++;
                            }
                        }
                        else if(countCollumns == 3){
                            if (orderCountAux%5 == 1) {
                                path = "2122232425151102526271707P4"; //Mc1
                            }
                            else if (orderCountAux%5 == 2) {
                                path = "212223241412014115242526271707P4"; //Mb1
                            }
                            else if (orderCountAux%5 == 3) {
                                path = "2122232425151102526271707P4"; //Mc1
                            }
                            else if (orderCountAux%5 == 4) {
                                path = "2122232425151102526271707P4"; //Mc1
                            }
                            else if (orderCountAux%5 == 0) {
                                path = "2122232425151102526271707P4"; //Mc1
                            }
                            if(orderCountAux==orderUnitsToDo || orderCountAux%5== 0){
                                countCollumns=1;
                            }
                        }
                    }
                    break;


                case "P5":
                    if(orderUnitsToDo <=3){
                        if (countCollumns == 1) {
                            path = "2131415161626364655511055130656667574737271707P5"; //Mc3

                            if (orderCountAux == orderUnitsToDo) {
                                countCollumns++;
                            }
                        } else if (countCollumns == 2) {
                            path = "21314142434445351103513045464737271707P5"; //Mc2

                            if (orderCountAux == orderUnitsToDo) {
                                countCollumns++;
                            }
                        } else if (countCollumns == 3) {
                            path = "212223242515110151302526271707P5"; //Mc1

                            if (orderCountAux == orderUnitsToDo) {
                                countCollumns = 1;
                            }
                        }

                    }
                    else {
                        if (countCollumns == 1) {
                            if(orderCountAux%4 == 1) {
                                path = "2131415161626364655511055130656667574737271707P5"; //Mc3
                            }
                            else if(orderCountAux%4 == 2){
                                path = "21314151616263645412054115646555130656667574737271707P5"; //Mb3+Mc3
                            }
                            else if(orderCountAux%4 == 3) {
                                path = "2131415161626364655511055130656667574737271707P5"; //Mc3
                            }
                            else if(orderCountAux%4 == 0) {
                                path = "2131415161626364655511055130656667574737271707P5"; //Mc3
                            }

                            if (orderCountAux == orderUnitsToDo || orderCountAux % 4 == 0) {
                                countCollumns++;
                            }
                        }
                        else if (countCollumns == 2) {

                            if(orderCountAux%4 == 1) {
                                path = "21314142434445351103513045464737271707P5"; //Mc2
                            }
                            else if(orderCountAux%4 == 2){
                                path = "213141424344341203411544453513045464737271707P5"; //Mb2+Mc2
                            }
                            else if(orderCountAux%4 == 3) {
                                path = "21314142434445351103513045464737271707P5"; //Mc2
                            }
                            else if(orderCountAux%4 == 0) {
                                path = "21314142434445351103513045464737271707P5"; //Mc2
                            }

                            if (orderCountAux == orderUnitsToDo || orderCountAux % 4 == 0) {
                                countCollumns++;
                            }

                        }
                        else if (countCollumns == 3) {

                            if(orderCountAux%4 == 1) {
                                path = "212223242515110151302526271707P5"; //Mc1
                            }
                            else if(orderCountAux%4 == 2){
                                path = "2122232414120141152425151302526271707P5"; //Mb1+Mc1
                            }
                            else if(orderCountAux%4 == 3) {
                                path = "212223242515110151302526271707P5"; //Mc1
                            }
                            else if(orderCountAux%4 == 0) {
                                path = "212223242515110151302526271707P5"; //Mc1
                            }

                            if (orderCountAux == orderUnitsToDo || orderCountAux % 4 == 0) {
                                countCollumns=1;
                            }
                        }

                    }
                    break;

/*
                case "P6":
                    "21314151616263531154333215434445464737271707P6"
                    "21222313115233321523242526271707P6"
                case "P7":
                    "21314151616263645412044342204445464737271707P7"
                    "21222324141202434220242526271707P7"

                    "21314151616263531155311563645422064656667574737271707P7"
                    "213141424333115331154344342204445464737271707P7"
                    "2122231311513115232414220242526271707P7"

                case "P8":
                    "21314151616263645412054115646555210656667574737271707P8"
                    "213141424344341203411544453521045464737271707P8"
                    "2122232414120141152425152102526271707P8"

                    "21314151616263646555110453521045464737271707P8"
                    "21222324251511025352102526271707P8"
*/
                case "P9":

                    if(orderUnitsToDo <= 4){
                        path = "21222324251511025352104555310656667574737271707P9"; //Mc1+Mc2+Mc3

                        if (orderCountAux == orderUnitsToDo) {
                            countCollumns=3;
                        }
                    }
                    else if (orderUnitsToDo <= 15) {
                        while(bigFlagP1P9Init){
                            boolean p41=SFS.getCell(1,4).getUnitPresence();
                            boolean p42=SFS.getCell(2,4).getUnitPresence();
                            boolean p43=SFS.getCell(3,4).getUnitPresence();
                            boolean p61=SFS.getCell(1,6).getUnitPresence();
                            boolean p62=SFS.getCell(2,6).getUnitPresence();
                            boolean p63=SFS.getCell(3,6).getUnitPresence();


                            if(!p41 && !p42 && !p43 && !p61 && !p62 && !p63){
                                bigFlagP1P9Init=false;
                            }

                        }

                        if (orderCountAux % 3 == 1) {
                            path = "21222324251511025352104555310656667574737271707P9"; //Mc1+Mc2+Mc3
                        } else if (orderCountAux % 3 == 2) {
                            path = "21222324251511025352104555310656667574737271707P9"; //Mc1+Mc2+Mc3
                        } else if (orderCountAux % 3 == 0) {
                            path = "21222313115233321543533156364656667574737271707P9"; //Ma1+Ma2+Ma3
                        }

                        if (orderCountAux == orderUnitsToDo) {
                            bigFlagP1P9End=true;
                            bigFlagP1P9Init=true;
                            countCollumns = 3;
                        }
                    }
                    else{
                        while(bigFlagP1P9Init){
                            boolean p41=SFS.getCell(1,4).getUnitPresence();
                            boolean p42=SFS.getCell(2,4).getUnitPresence();
                            boolean p43=SFS.getCell(3,4).getUnitPresence();
                            boolean p61=SFS.getCell(1,6).getUnitPresence();
                            boolean p62=SFS.getCell(2,6).getUnitPresence();
                            boolean p63=SFS.getCell(3,6).getUnitPresence();

                            if(!p41 && !p42 && !p43 && !p61 && !p62 && !p63){
                                bigFlagP1P9Init=false;
                            }

                        }

                        if (orderCountAux%5 == 1) {
                            path = "21222324251511025352104555310656667574737271707P9"; //Mc1+Mc2+Mc3
                        }
                        else if (orderCountAux%5 == 2) {
                            path = "21222324141202434220445432064656667574737271707P9"; //Mb1+Mb2+Mb3
                        }
                        else if (orderCountAux%5 == 3) {
                            path = "21222313115233321543533156364656667574737271707P9"; //Ma1+Ma2+Ma3
                        }
                        else if (orderCountAux%5 == 4) {
                            path = path = "21222324251511025352104555310656667574737271707P9"; //Mc1+Mc2+Mc3
                        }
                        else if (orderCountAux%5 == 0) {
                            path = "21222313115233321543533156364656667574737271707P9"; //Ma1+Ma2+Ma3
                        }

                        if(orderCountAux==orderUnitsToDo){
                            bigFlagP1P9End=true;
                            bigFlagP1P9Init=true;
                            countCollumns=3;
                        }

                    }
                    break;

            }
        }
        else if (orderPx.equals("P2")) {
            switch (orderPy) {
                case "P3":
                    if (countCollumns==1){
                        path = "21314151616263531156364656667574737271707P3"; //Ma3

                        countCollumns++;
                    }
                    else if(countCollumns == 2){
                        path = "213141424333115434445464737271707P3"; //Ma2

                        countCollumns++;
                    }
                    else if(countCollumns == 3){
                        path = "2122231311523242526271707P3"; //Ma1
                        countCollumns=1;
                    }
                    break;
                case "P4":
                    if (countCollumns==1){
                        path = "213141516162635311563645411564656667574737271707P4"; //Ma3 + Mb3
                        countCollumns++;
                    }
                    else if(countCollumns == 2){
                        path = "2131414243331154344341154445464737271707P4"; //Ma2 + Mb2
                        countCollumns++;
                    }
                    else if(countCollumns == 3){
                        path = "21222313115232414115242526271707P4"; //Ma1 + Mb1
                        countCollumns=1;
                    }
                    break;

                case "P5":
                    if(orderUnitsToDo <=3){
                        if (countCollumns == 1) {
                            path = "2131415161626353115636454115646555130656667574737271707P5"; //Ma3 + Mb3 + Mc3
                        } else if (countCollumns == 2) {
                            path = "21314142433311543443411544453513045464737271707P5"; //Ma2 + Mb2 + Mc2
                        } else if (countCollumns == 3) {
                            path = "212223131152324141152425151302526271707P5"; //Ma1 + Mb1 + Mc1
                        }

                        if(orderUnitsToDo == orderCountAux){
                            if(countCollumns == 3) countCollumns=1;
                            else countCollumns++;
                        }

                    }
                    else {
                        if (countCollumns == 1) {
                            path = "2131415161626353115636454115646555130656667574737271707P5"; //Ma3 + Mb3 + Mc3
                            countCollumns++;
                        } else if (countCollumns == 2) {
                            path = "21314142433311543443411544453513045464737271707P5"; //Ma2 + Mb2 + Mc2
                            countCollumns++;
                        } else if (countCollumns == 3) {
                            path = "212223131152324141152425151302526271707P5"; //Ma1 + Mb1 + Mc1
                            countCollumns = 1;
                        }
                    }

                    break;
                case "P6":
                    if (countCollumns==1){
                        path = "21314151616263532156364656667574737271707P6"; //Ma3
                        countCollumns++;
                    }
                    else if(countCollumns == 2){
                        path = "213141424333215434445464737271707P6"; //Ma2
                        countCollumns++;
                    }
                    else if(countCollumns == 3){
                        path = "2122231321523242526271707P6"; //Ma1
                        countCollumns=1;
                    }
                    break;
                case "P7":
                    if (countCollumns==1){
                        path = "213141516162635311563645422064656667574737271707P7"; //Ma3 + Mb3
                        countCollumns++;
                    }
                    else if(countCollumns == 2){
                        path = "2131414243331154344342204445464737271707P7"; //Ma2 + Mb2
                        countCollumns++;
                    }
                    else if(countCollumns == 3){
                        path = "21222313115232414220242526271707P7"; //Ma1 + Mb1
                        countCollumns=1;
                    }
                    break;
                case "P8":
                    if(orderUnitsToDo <=3){
                        if (countCollumns == 1) {
                            path = "2131415161626353115636454115646555210656667574737271707P8"; //Ma3 + Mb3 + Mc3
                        } else if (countCollumns == 2) {
                            path = "21314142433311543443411544453521045464737271707P8"; //Ma2 + Mb2 + Mc2
                        } else if (countCollumns == 3) {
                            path = "212223131152324141152425152102526271707P8"; //Ma1 + Mb1 + Mc1
                        }

                        if(orderUnitsToDo == orderCountAux){
                            if(countCollumns == 3) countCollumns=1;
                            else countCollumns++;
                        }

                    }
                    else {
                        if (countCollumns == 1) {
                            path = "2131415161626353115636454115646555210656667574737271707P8"; //Ma3 + Mb3 + Mc3
                            countCollumns++;
                        } else if (countCollumns == 2) {
                            path = "21314142433311543443411544453521045464737271707P8"; //Ma2 + Mb2 + Mc2
                            countCollumns++;
                        } else if (countCollumns == 3) {
                            path = "212223131152324141152425152102526271707P8"; //Ma1 + Mb1 + Mc1
                            countCollumns = 1;
                        }
                    }

                    break;
                case "P9":
                    //213141516162635311563645411564655521045353102526271707p9
                    //213141424333215231331523242526271707p9
                    //21314151616263531156364542204434320242526271707p9
                    break;
            }
        }
        else if (orderPx.equals("P3")) {
            switch (orderPy) {
                case "P4":
                    if (countCollumns==1){
                        path = "21314151616263645411564656667574737271707P4"; //Mb3
                        countCollumns++;
                    }
                    else if(countCollumns == 2){
                        path = "213141424344341154445464737271707P4"; //Mb2
                        countCollumns++;
                    }
                    else if(countCollumns == 3){
                        path = "2122232414115242526271707P4"; //Mb1
                        countCollumns=1;
                    }
                    break;
                case "P5":

                    if (countCollumns == 1) {
                        path="213141516162636454115646555130656667574737271707P5"; //Mb3+Mc3

                        if (orderCountAux == orderUnitsToDo || orderCountAux % 3 == 0) {
                            countCollumns++;
                        }
                    }
                    else if (countCollumns == 2) {

                        path="2131414243443411544453513045464737271707P5"; //Mb2+Mc2

                        if (orderCountAux == orderUnitsToDo || orderCountAux % 3 == 0) {
                            countCollumns++;
                        }

                    }
                    else if (countCollumns == 3) {
                        path="21222324141152425151302526271707P5"; //Mb1+Mc1

                        if (orderCountAux == orderUnitsToDo || orderCountAux % 3 == 0) {
                            countCollumns=1;
                        }
                    }

                    break;

                case "P7":
                    if (countCollumns==1){
                        path = "21314151616263645422064656667574737271707P7"; //Mb3
                        countCollumns++;
                    }
                    else if(countCollumns == 2){
                        path = "213141424344342204445464737271707P7"; //Mb2
                        countCollumns++;
                    }
                    else if(countCollumns == 3){
                        path = "2122232414220242526271707P7"; //Mb1
                        countCollumns=1;
                    }
                    break;
                case "P8":
                    if (countCollumns==1){
                        path = "213141516162636454115646555210656667574737271707P8"; //Mb3 + Mc3
                        countCollumns++;
                    }
                    else if(countCollumns == 2){
                        path = "2131414243443411544453521045464737271707P8"; //Mb2 + Mc2
                        countCollumns++;
                    }
                    else if(countCollumns == 3){
                        path = "21222324141152425152102526271707P8"; //Mb1 + Mc1
                        countCollumns=1;
                    }
                    break;

                case "P9":
                    //
                    //
                    //
                    break;
            }
        }
        else if (orderPx.equals("P4")) {
            switch (orderPy) {
                case "P5":
                    if (countCollumns == 1) {
                        path = "21314151616263646555130656667574737271707P5"; //Mc3

                        countCollumns++;
                    } else if (countCollumns == 2) {

                        path = "213141424344453513045464737271707P5"; //Mc2

                        countCollumns++;

                    } else if (countCollumns == 3) {

                        path = "2122232425151302526271707P5"; //Mc1

                        countCollumns=1;
                    }

                    break;

                case "P8":
                    if (countCollumns == 1) {
                        path = "21314151616263646555210656667574737271707P8"; //Mc3
                        countCollumns++;
                    }
                    else if (countCollumns == 2) {
                        path = "213141424344453521045464737271707P8"; //Mc2
                        countCollumns++;
                    }
                    else if (countCollumns == 3) {
                        path = "2122232425152102526271707P8"; //Mc1
                        countCollumns=1;
                    }

                    break;
                case "P9":
                    //2131415161626364655521045353102526271707p9
                    //
                    //
                    break;
            }
        }
        else if (orderPx.equals("P6") && orderPy.equals("P9")) {
            if (countCollumns == 1) {
                path = "21314151616263533156364656667574737271707P9"; //Ma3
                countCollumns++;
            }
            else if (countCollumns == 2) {
                path = "213141424333315434445464737271707P9"; //Ma2
                countCollumns++;
            }
            else if (countCollumns == 3) {
                path = "2122231331523242526271707P9"; //Ma1
                countCollumns=1;
            }
        }
        else if (orderPx.equals("P7") && orderPy.equals("P9")) {
            if (orderUnitsToDo <= 3) {
                if (countCollumns == 1) {
                    path = "21314151616263645432064656667574737271707P9"; //Mb3

                    if (orderCountAux == orderUnitsToDo) {
                        countCollumns++;
                    }
                }
                else if (countCollumns == 2) {
                    path = "213141424344343204445464737271707P9"; //Mb2

                    if (orderCountAux == orderUnitsToDo) {
                        countCollumns++;
                    }
                } else if (countCollumns == 3) {
                    path = "2122232414320242526271707P9"; //Mb1
                    if (orderCountAux == orderUnitsToDo) {
                        countCollumns=1;
                    }
                }
            }
            else {
                if (countCollumns == 1) {
                    path = "21314151616263645432064656667574737271707P9"; //Mb3
                    countCollumns++;

                } else if (countCollumns == 2) {
                    path = "213141424344343204445464737271707P9"; //Mb2
                    countCollumns++;

                } else if (countCollumns == 3) {
                    path = "2122232414320242526271707P9"; //Mb1
                    countCollumns=1;

                }

            }
        }
        else if (orderPx.equals("P8") && orderPy.equals("P9")) {
            if (countCollumns == 1) {
                path = "21314151616263645432064656667574737271707P9"; //Mc3
                countCollumns++;
            }
            else if (countCollumns == 2) {
                path = "213141424344343204445464737271707P9"; //Mc2
                countCollumns++;
            }
            else if (countCollumns == 3) {
                path = "2122232414320242526271707P9"; //Mc1
                countCollumns=1;
            }
        }


        if(parallel) countCollumns=countCollumnsInitial;
        return path;
    }


    private String isCompatible(String orderPxNow,String orderPyNow,String orderPxCompatible,String orderPyCompatible){
        String compatible="";
        boolean maNow = false;
        boolean mbNow = false;
        boolean mcNow=false;
        boolean maCompatible =false, mbCompatible=false, mcCompatible = false;

        if((orderPxNow.equals("P1") && orderPyNow.equals("P2")) || (orderPxNow.equals("P2") && orderPyNow.equals("P6")) || (orderPxNow.equals("P6") && orderPyNow.equals("P9")) || (orderPxNow.equals("P2") && orderPyNow.equals("P3"))){
            compatible=compatible + "1";
        }
        else if ((orderPxNow.equals("P3") && orderPyNow.equals("P7")) || (orderPxNow.equals("P7") && orderPyNow.equals("P9")) || (orderPxNow.equals("P3") && orderPyNow.equals("P4"))){
            compatible=compatible + "2";
        }
        else if((orderPxNow.equals("P4") && orderPyNow.equals("P5")) || (orderPxNow.equals("P4") && orderPyNow.equals("P8")) || (orderPxNow.equals("P8") && orderPyNow.equals("P9"))){
            compatible=compatible + "3";
        }

        if((orderPxCompatible.equals("P1") && orderPyCompatible.equals("P2")) || (orderPxCompatible.equals("P2") && orderPyCompatible.equals("P6")) || (orderPxCompatible.equals("P6") && orderPyCompatible.equals("P9")) || (orderPxCompatible.equals("P2") && orderPyCompatible.equals("P3"))){
            compatible=compatible + "1";
        }
        else if ((orderPxCompatible.equals("P1") && orderPyCompatible.equals("P3")) || (orderPxCompatible.equals("P7") && orderPyCompatible.equals("P9")) || (orderPxCompatible.equals("P3") && orderPyCompatible.equals("P4"))){
            compatible=compatible + "2";
        }

        else if((orderPxCompatible.equals("P1") && orderPyCompatible.equals("P4")) || (orderPxCompatible.equals("P4") && orderPyCompatible.equals("P5")) || (orderPxCompatible.equals("P4") && orderPyCompatible.equals("P8")) || (orderPxCompatible.equals("P8") && orderPyCompatible.equals("P9"))){
            compatible=compatible + "3";
        }
        else if((orderPxCompatible.equals("P3") && orderPyCompatible.equals("P8")) || (orderPxCompatible.equals("P3") && orderPyCompatible.equals("P5"))){
            compatible=compatible + "23";
        }
        else if((orderPxCompatible.equals("P2") && orderPyCompatible.equals("P4")) || (orderPxCompatible.equals("P2") && orderPyCompatible.equals("P7"))){
            compatible=compatible + "12";
        }

        return compatible;
    }


    private int getMaxPriority(){
        orderTransform maxPriority = ordersPriority.get(0);
        orderTransform maxPriorityNew;
        int maxPriorityIndex=0;

        for(int i=1; i < ordersPriority.size(); i++){
            maxPriorityNew=ordersPriority.get(i);

            if(maxPriorityNew.getIdealEndTime() < maxPriority.getIdealEndTime()){
              maxPriority=maxPriorityNew;
              maxPriorityIndex=i;
            }

        }

        return maxPriorityIndex;
    }
}
